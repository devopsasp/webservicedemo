package com.service.client;
import org.apache.cxf.Bus;
import org.apache.cxf.BusFactory;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.ws.security.wss4j.WSS4JInInterceptor;

import org.apache.wss4j.dom.handler.WSHandlerConstants;
import java.util.HashMap;
import java.util.Map;
public class WeatherServicePublisher {
	
	public static void main(String args[])
	{
		/*Bus bus = BusFactory.getDefaultBus();

        // Configure WS-Security properties
        Map<String, Object> inProps = new HashMap<>();
        inProps.put(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
        inProps.put(WSHandlerConstants.PASSWORD_TYPE, "PasswordText");
        inProps.put(WSHandlerConstants.PW_CALLBACK_CLASS, "com.service.client.PasswordCallback");
        WSS4JInInterceptor wssIn = new WSS4JInInterceptor(inProps);
        bus.getInInterceptors().add(wssIn);
        EndpointImpl endpoint = new EndpointImpl(bus, new WeatherServiceImpl());
        endpoint.publish("http://localhost:8987/weather");
        System.out.println("Service published at http://localhost:8987/weather?wsdl");
   */
		Bus bus = BusFactory.getDefaultBus();

		Map<String, Object> inProps = new HashMap<>();
		inProps.put(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
		inProps.put(WSHandlerConstants.PASSWORD_TYPE, "PasswordText");
		inProps.put(WSHandlerConstants.PW_CALLBACK_CLASS, "com.service.client.PasswordCallback");

		WSS4JInInterceptor wssIn = new WSS4JInInterceptor(inProps);

		EndpointImpl endpoint = new EndpointImpl(bus, new WeatherServiceImpl());
		endpoint.getInInterceptors().add(wssIn);   // attach directly to endpoint
		endpoint.publish("http://localhost:8987/weather");

		System.out.println("Service published at http://localhost:8987/weather?wsdl");

    
    }
	
	
	}


