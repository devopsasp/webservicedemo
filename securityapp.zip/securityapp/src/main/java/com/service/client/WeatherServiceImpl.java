package com.service.client;
import java.util.HashMap;

import javax.jws.WebService;
@WebService(
	    endpointInterface = "com.service.client.WeatherService",
	    targetNamespace = "http://client.service.com/",
	    serviceName = "WeatherServiceImplService",
	    portName = "WeatherServiceImplPort"
	)
public class WeatherServiceImpl implements WeatherService{

	@Override
	public String getReport(String city) {
		
		HashMap<String ,String> weatherData=new HashMap<>();
		weatherData.put("Chennai","Partly cloudy ,expected to rain");
		weatherData.put("Delhi","Fog, low visibility with chillness");
		weatherData.put("Mumbai", "sunny with clear sky");
		weatherData.put("Kolkata", "Windy with humidity");
		weatherData.put("Baglore","Pleasent weather with cloudy sky,can rain");
		// TODO Auto-generated method stub
		return weatherData.get(city);
	}

}
