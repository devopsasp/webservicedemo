@javax.xml.bind.annotation.XmlSchema(namespace = "http://client.service.com/")
package com.service.client;
