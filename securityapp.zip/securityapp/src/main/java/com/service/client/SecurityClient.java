package com.service.client;

import java.util.HashMap;
import java.util.Map;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.wss4j.dom.handler.WSHandlerConstants;

public class SecurityClient {
	public static void main(String args[])
	{ 
		WeatherServiceImplService service=new WeatherServiceImplService();
		WeatherService port=service.getWeatherServiceImplPort();
		 Map<String, Object> outProps = new HashMap<>();
	        outProps.put(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
	        outProps.put(WSHandlerConstants.USER, "admin");
	        outProps.put(WSHandlerConstants.PASSWORD_TYPE, "PasswordText");
	        outProps.put(WSHandlerConstants.PW_CALLBACK_CLASS, "com.service.client.PasswordCallback");

	        WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(outProps);
	       
	        Client client = ClientProxy.getClient(port);
	        client.getOutInterceptors().add(wssOut);
		String response=port.getReport("Delhi");
		System.out.println(response);
	}

}
